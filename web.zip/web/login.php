<?php
session_start();
require_once('db_config.php');


if(isset($_SESSION['user_id'])){
    header('Location: index.php');
    exit;
}


if($_SERVER['REQUEST_METHOD'] == 'POST'){

    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    
    $query = "SELECT id, username, password, role FROM users WHERE username = ? LIMIT 1";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if($user && password_verify($password, $user['password']) && $user['role'] == $role){
        $_POST['user_id'] = $user['id'];
        $_POST['role'] = $user['role'];
        header('Location: index.php');
        exit;
    } else {
        $error = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <?php if(isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php ?>
    <form method="POST">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div>
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="">Select Role</option>
                <option value="producer">Producer</option>
                <option value="consumer">Consumer</option>
            </select>
        </div>
        <div>
            <button type="submit">Login</button>
        </div>
    </form>
</body>
</html>